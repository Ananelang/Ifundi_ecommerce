

from django.test import TestCase
from django.urls import reverse
from shop.models import Product

class ProductListViewTest(TestCase):

    def test_product_list_view(self):
        response = self.client.get(reverse('product_list'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'shop/product_list.html')

class AddProductViewTest(TestCase):

    def test_add_product_view_get(self):
        response = self.client.get(reverse('add_product'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'shop/add_product.html')

    def test_add_product_view_post(self):
        data = {
            'name': 'Test Product',
            'description': 'Test Description',
            'price': 10.00,
            'stock': 100
        }
        response = self.client.post(reverse('add_product'), data)
        self.assertEqual(response.status_code, 302)  
        self.assertTrue(Product.objects.filter(name='Test Product').exists())
