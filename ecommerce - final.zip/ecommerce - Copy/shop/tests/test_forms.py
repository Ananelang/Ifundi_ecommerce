

from django.test import TestCase
from shop.forms import ProductForm

class ProductFormTest(TestCase):

    def test_valid_form(self):
        data = {
            'name': 'Test Product',
            'description': 'Test Description',
            'price': 10.00,
            'stock': 100
        }
        form = ProductForm(data)
        self.assertTrue(form.is_valid())

    def test_invalid_form(self):
        data = {
            'name': '',
            'description': 'Test Description',
            'price': 10.00,
            'stock': 100
        }
        form = ProductForm(data)
        self.assertFalse(form.is_valid())
        self.assertIn('name', form.errors)
