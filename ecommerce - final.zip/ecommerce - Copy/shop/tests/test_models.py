# shop/tests/test_models.py

from django.test import TestCase
from shop.models import Product

class ProductModelTest(TestCase):

    def test_create_product(self):
        product = Product.objects.create(
            name='Test Product',
            description='Test Description',
            price=10.00,
            stock=100
        )
        self.assertEqual(product.name, 'Test Product')
        self.assertEqual(product.description, 'Test Description')
        self.assertEqual(product.price, 10.00)
        self.assertEqual(product.stock, 100)
